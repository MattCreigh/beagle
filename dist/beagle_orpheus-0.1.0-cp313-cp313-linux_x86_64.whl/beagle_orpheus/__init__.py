"""beagle-orpheus — proprietary native transport wheel for beagle.

FlatBuffers-framed connections over Orpheus shared-memory ring buffers,
compiled to C. Separately licensed: free for evaluation and limited single
use; a paid license is required for production or business deployment.

Auto-detected by beagle via the ``beagle.transports`` entry-point group.
Detection NEVER activates it — set ``$BEAGLE_TRANSPORT=orpheus`` or
``[connections] transport = "orpheus"`` in ~/.config/beagle to switch.
"""
from __future__ import annotations as _o8c9389beb688
__version__ = '0.1.0'
PLUGIN_NAME = 'orpheus'
TRANSPORT_DESCRIPTION = 'Proprietary native FlatFrames over Orpheus rings (compiled C)'

def factory() -> object:
    """Entry-point factory for ``beagle.transports`` discovery."""
    from .transport import factory as _ob05ccb51771e
    return _ob05ccb51771e()
from .compat import A2AMessage
from .compat import MessageType
from .compat import OrpheusClient
from .compat import TaskType
from .compat import cleanup_rings
from .compat import create_rings
from .compat import get_ipc
from .compat import get_orpheus_client
__all__ = ['A2AMessage', 'MessageType', 'OrpheusClient', 'TaskType', 'TRANSPORT_DESCRIPTION', '__version__', 'cleanup_rings', 'create_rings', 'factory', 'get_ipc', 'get_orpheus_client']